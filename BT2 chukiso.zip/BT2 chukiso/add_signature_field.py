from pypdf import PdfWriter, PdfReader
from pypdf.generic import (
    NameObject,
    DictionaryObject,
    NumberObject,
    RectangleObject,
    ArrayObject,
)

# 1️⃣ Đọc file PDF gốc
input_pdf = PdfReader("original.pdf")

# 2️⃣ Tạo writer để ghi file mới
writer = PdfWriter()
for page in input_pdf.pages:
    writer.add_page(page)

# 3️⃣ Tạo annotation (ô chữ ký)
signature_field = DictionaryObject()
signature_field.update({
    NameObject("/FT"): NameObject("/Sig"),          # Field Type = Signature
    NameObject("/T"): NameObject("/Signature1"),     # ✅ Sửa lỗi ở đây (thêm '/')
    NameObject("/Ff"): NumberObject(0),
    NameObject("/Rect"): RectangleObject([100, 100, 300, 150]),  # vị trí ô chữ ký
    NameObject("/Subtype"): NameObject("/Widget"),
    NameObject("/Type"): NameObject("/Annot"),
    NameObject("/P"): writer.pages[0].indirect_reference,
})

# 4️⃣ Thêm annotation vào trang đầu
page0 = writer.pages[0]
if "/Annots" not in page0:
    page0[NameObject("/Annots")] = ArrayObject()
page0["/Annots"].append(signature_field)

# 5️⃣ Ghi ra file PDF mới
with open("unsigned.pdf", "wb") as f_out:
    writer.write(f_out)

print("✅ Đã thêm trường chữ ký vào file unsigned.pdf")
