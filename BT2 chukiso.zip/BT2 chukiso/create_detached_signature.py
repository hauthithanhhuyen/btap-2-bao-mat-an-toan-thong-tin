from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
from asn1crypto import cms, pem, algos, x509
from datetime import datetime

# --- Bước 1: Tải file cần ký ---
input_file = "original.pdf"
with open(input_file, "rb") as f:
    data = f.read()

# --- Bước 2: Đọc file chứng chỉ P12 ---
p12_file = "mycert.p12"
p12_password = b"123456"

with open(p12_file, "rb") as f:
    p12_data = f.read()
p12 = pkcs12.load_key_and_certificates(p12_data, p12_password, backend=default_backend())

private_key = p12[0]
cert = p12[1]

# --- Bước 3: Băm dữ liệu ---
digest = hashes.Hash(hashes.SHA256(), backend=default_backend())
digest.update(data)
digest_bytes = digest.finalize()

# --- Bước 4: Ký chữ ký RSA ---
signature = private_key.sign(
    digest_bytes,
    padding.PKCS1v15(),
    hashes.SHA256()
)

# --- Bước 5: Chuyển chứng chỉ sang asn1crypto.x509.Certificate ---
cert_asn1 = x509.Certificate.load(cert.public_bytes(serialization.Encoding.DER))

# --- Bước 6: Tạo cấu trúc CMS Detached ---
digest_algorithm = algos.DigestAlgorithm({'algorithm': 'sha256'})
signer_info = cms.SignerInfo({
    'version': 'v1',
    'sid': cms.SignerIdentifier({'issuer_and_serial_number': cms.IssuerAndSerialNumber({
        'issuer': cert_asn1.issuer,
        'serial_number': cert_asn1.serial_number,
    })}),
    'digest_algorithm': digest_algorithm,
    'signature_algorithm': algos.SignedDigestAlgorithm({'algorithm': 'rsa'}),
    'signature': signature,
})

content_info = cms.ContentInfo({
    'content_type': 'data',
    'content': None  # Detached signature => không đính kèm dữ liệu
})

signed_data = cms.SignedData({
    'version': 'v1',
    'digest_algorithms': [digest_algorithm],
    'encap_content_info': content_info,
    'certificates': [cert_asn1],
    'signer_infos': [signer_info],
})

cms_data = cms.ContentInfo({
    'content_type': 'signed_data',
    'content': signed_data
})

# --- Bước 7: Xuất file .p7s ---
output_file = "original.p7s"
with open(output_file, "wb") as f:
    f.write(cms_data.dump())

print("✅ Đã tạo chữ ký detached:", output_file)
