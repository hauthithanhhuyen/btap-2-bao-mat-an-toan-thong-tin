from pypdf import PdfReader
import sys

def inspect_signatures(pdf_path):
    print(f"\n=== Đang kiểm tra chữ ký trong: {pdf_path} ===\n")
    reader = PdfReader(pdf_path)

    if "/AcroForm" not in reader.trailer["/Root"]:
        print("❌ Tệp PDF không chứa trường chữ ký nào.")
        return

    sig_fields = reader.trailer["/Root"]["/AcroForm"].get("/Fields", [])

    if not sig_fields:
        print("❌ Không tìm thấy trường chữ ký nào.")
        return

    for i, field in enumerate(sig_fields, 1):
        field_obj = field.get_object()
        if field_obj.get("/FT") == "/Sig":
            sig = field_obj.get("/V")
            if sig:
                print(f"--- Chữ ký số #{i} ---")
                print(f"Tên người ký: {sig.get('/Name')}")
                print(f"Lý do ký: {sig.get('/Reason')}")
                print(f"Địa điểm: {sig.get('/Location')}")
                print(f"Thời gian: {sig.get('/M')}")
                print(f"ByteRange: {sig.get('/ByteRange')}")
                print(f"Chiều dài nội dung chữ ký (/Contents): {len(sig.get('/Contents')) if sig.get('/Contents') else 'N/A'}")
                print("-" * 60)
            else:
                print(f"⚠️ Trường #{i} không có dữ liệu chữ ký.")
        else:
            print(f"⚠️ Trường #{i} không phải kiểu chữ ký (/Sig).")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Cách dùng: python inspect_signatures.py <đường_dẫn_tệp_PDF>")
    else:
        inspect_signatures(sys.argv[1])
