from PIL import Image
import fitz  # PyMuPDF
import os

# === Đặt tên file ===
pdf_file = "signed_output.pdf"          # PDF đã có chữ ký số
output_file = "signed_with_image.pdf"   # PDF đầu ra
original_img = "huyen_sign_fixed.png"   # ảnh chữ ký tay  (chú ý có dấu cách)

# === B1: Kiểm tra ảnh tồn tại ===
if not os.path.exists(original_img):
    print(f"⚠️ Không tìm thấy ảnh: {original_img}")
    print("👉 Hãy chắc chắn file ảnh nằm cùng thư mục với file .py này.")
    exit()

# === B2: Chuẩn hóa ảnh sang JPG nếu cần ===
try:
    with Image.open(original_img) as img:
        img = img.convert("RGB")
        fixed_img_path = "signature_fixed_real.jpg"
        img.save(fixed_img_path, format="JPEG")
        print("✅ Ảnh đã chuẩn hóa thành JPEG:", fixed_img_path)
except Exception as e:
    print("⚠️ Lỗi khi xử lý ảnh:", e)
    exit()

# === B3: Chèn ảnh + text vào PDF ===
try:
    doc = fitz.open(pdf_file)
    page = doc[0]

    # 📌 Chỉnh lại vị trí & kích thước ảnh cho to hơn, rõ nét hơn
    rect = fitz.Rect(330, 80, 580, 200)  # x1, y1, x2, y2 — tăng vùng ảnh
    page.insert_image(rect, filename=fixed_img_path)

    # 📌 Thêm chữ ký và ngày ký, phóng to hơn và dịch xuống dưới một chút
    page.insert_text((360, 210), "hauthanhhuyen", fontsize=14, color=(0, 0, 0))
    page.insert_text((360, 230), "Ngày ký: 27/10/2025", fontsize=12, color=(0, 0, 0))

    doc.save(output_file)
    doc.close()
    print("✅ Đã chèn ảnh & chữ ký tay vào PDF:", output_file)
except Exception as e:
    print("⚠️ Lỗi khi chèn ảnh:", e)
