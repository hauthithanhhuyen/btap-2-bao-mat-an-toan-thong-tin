# === sign_pdf_real_final.py ===
from endesive.pdf.cms import sign
from cryptography.hazmat.primitives.serialization import pkcs12
from datetime import datetime, timezone, timedelta

# === 1. Đọc file PDF chưa ký (đã có ảnh chữ ký tay) ===
with open('signed_with_image.pdf', 'rb') as f:
    pdf_data = f.read()

# === 2. Đọc khóa và chứng chỉ từ file .p12 ===
# 👉 Đặt file chứng chỉ của bạn (VD: mycert.p12) cùng thư mục này
with open('mycert.p12', 'rb') as f:
    p12_data = f.read()

# === 3. Nhập mật khẩu file .p12 (nếu có) ===
private_key, cert, extra_certs = pkcs12.load_key_and_certificates(p12_data, b"123456")  # đổi 1234 nếu khác

# === 4. Thông tin ký số ===
vn_time = datetime.now(timezone.utc) + timedelta(hours=7)
date_str = vn_time.strftime("D:%Y%m%d%H%M%S+07'00'")

sign_info = {
    "sigflags": 3,
    "contact": "hauthanhhuyen@example.com",
    "location": "Thai Nguyen, Viet Nam",
    "signingdate": date_str,
    "reason": "Xác nhận nội dung tài liệu",
    "signature": "Signed by Hau Thanh Huyen",
    "signer": "Hau Thanh Huyen",
}

# === 5. Ký số PDF ===
signed_pdf = sign(
    datau=pdf_data,
    udct=sign_info,
    key=private_key,
    cert=cert,
    othercerts=extra_certs or [],
    algomd="sha256"
)

# === 6. Lưu file kết quả ===
with open("signed_final.pdf", "wb") as f:
    f.write(pdf_data + signed_pdf)

print("✅ Đã tạo file ký số: signed_final.pdf")
