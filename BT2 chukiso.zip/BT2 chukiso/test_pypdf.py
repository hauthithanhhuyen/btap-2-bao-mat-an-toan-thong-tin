import pypdf
print("✅ PyPDF đã cài thành công!")
