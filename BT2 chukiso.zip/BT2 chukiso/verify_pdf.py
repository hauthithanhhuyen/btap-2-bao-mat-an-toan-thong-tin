# === verify_pdf.py (FINAL – fix chữ ký không hợp lệ) ===
from PyPDF2 import PdfReader
from asn1crypto import cms, x509, tsp
from cryptography import x509 as crypto_x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from certvalidator import CertificateValidator, ValidationContext
import hashlib
import sys

def verify_pdf_signature(pdf_path):
    reader = PdfReader(pdf_path)
    acro_form = reader.trailer["/Root"].get("/AcroForm", {})
    fields = acro_form.get("/Fields", [])

    if not fields:
        print("❌ PDF không có AcroForm hoặc chữ ký.")
        return

    for i, field in enumerate(fields):
        field_obj = field.get_object()
        if "/V" not in field_obj:
            continue

        sig = field_obj["/V"].get_object()
        print(f"\n=== Signature field {i+1} ===")
        print("Tên người ký:", sig.get("/Name", "N/A"))
        print("Lý do ký:", sig.get("/Reason", "N/A"))
        print("Thời gian (/M):", sig.get("/M", "N/A"))
        print("ByteRange:", sig.get("/ByteRange", "N/A"))

        # --- 1️⃣ Hash vùng ByteRange ---
        byte_range = [int(x) for x in sig.get("/ByteRange")]
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()
        data_to_hash = pdf_bytes[byte_range[0]:byte_range[0]+byte_range[1]] + \
                       pdf_bytes[byte_range[2]:byte_range[2]+byte_range[3]]
        hash_value = hashlib.sha256(data_to_hash).digest()
        print("Hash tính từ ByteRange:", hash_value.hex())

        # --- 2️⃣ Đọc chữ ký CMS ---
        contents = sig["/Contents"]
        if isinstance(contents, str):
            contents = bytes.fromhex(contents)
        pkcs7_obj = cms.ContentInfo.load(contents)
        signed_data = pkcs7_obj['content']
        signer_info = signed_data['signer_infos'][0]
        cert_asn1 = signed_data['certificates'][0].chosen
        print("Certificate subject:", cert_asn1.subject.native)

        # --- 3️⃣ Lấy public key ---
        cert_crypto = crypto_x509.load_der_x509_certificate(cert_asn1.dump(), default_backend())
        public_key = cert_crypto.public_key()

        # --- 4️⃣ Lấy messageDigest trong signedAttrs ---
        try:
            signed_attrs = signer_info['signed_attrs']
            md_attr = next(a for a in signed_attrs if a['type'].native == 'message_digest')
            message_digest = md_attr['values'][0].native
        except Exception:
            message_digest = None

        # --- 5️⃣ Kiểm tra messageDigest khớp với hash file ---
        if message_digest and message_digest != hash_value:
            print("❌ Sai messageDigest – file PDF bị thay đổi.")
            continue

        # --- ✅ 6️⃣ Xác thực chữ ký (Endesive ký trên DER encoded signed_attrs) ---
        try:
            # Endesive -> signature = RSASSA-PKCS1v1.5( SHA256( signed_attrs.DER ) )
            data_signed = signer_info['signed_attrs'].dump()
            public_key.verify(
                signer_info['signature'].native,
                data_signed,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            print("✅ Chữ ký hợp lệ, PDF chưa bị sửa đổi.")
        except Exception as e:
            print("❌ Chữ ký không hợp lệ:", e)

        # --- 7️⃣ Kiểm tra certificate ---
        try:
            context = ValidationContext(allow_fetching=True, revocation_mode='soft-fail')
            validator = CertificateValidator(cert_asn1, None, context)
            validator.validate_usage(set(["digital_signature"]))
            print("✅ Certificate hợp lệ (OCSP/CRL kiểm tra xong).")
        except Exception as e:
            if "self-signed" in str(e).lower():
                print("⚠️ Certificate self-signed — bỏ qua OCSP/CRL (test).")
            else:
                print("❌ Certificate không hợp lệ:", e)

        # --- 8️⃣ Kiểm tra timestamp ---
        try:
            unsigned_attrs = signer_info['unsigned_attrs'] or []
            found_tsa = False
            for attr in unsigned_attrs:
                if attr['type'].native == 'signature_time_stamp_token':
                    tst_info = tsp.TimeStampToken.load(attr['values'][0].dump())
                    gen_time = tst_info['content']['tst_info']['gen_time'].native
                    print(f"🕒 Timestamp hợp lệ: {gen_time}")
                    found_tsa = True
                    break
            if not found_tsa:
                print("⚠️ Không tìm thấy timestamp RFC 3161 trong chữ ký.")
        except Exception as e:
            print("❌ Lỗi khi kiểm tra timestamp:", e)

    print("✅ Không phát hiện incremental update sau chữ ký.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Cách dùng: py verify_pdf.py <đường_dẫn_PDF>")
    else:
        verify_pdf_signature(sys.argv[1])
